import React, { useRef, useEffect } from 'react';
import { ModData } from '../types';

interface PreviewCanvasProps {
  modData: ModData;
  canvasRef: React.RefObject<HTMLCanvasElement>;
}

export const PreviewCanvas: React.FC<PreviewCanvasProps> = ({ modData, canvasRef }) => {
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas dimensions
    canvas.width = 1080;
    canvas.height = 1350; // Increased height for more content

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw background gradient based on template
    const gradient = ctx.createLinearGradient(0, 0, canvas.width, canvas.height);
    gradient.addColorStop(0, modData.customColors.background);
    gradient.addColorStop(0.5, modData.customColors.secondary);
    gradient.addColorStop(1, modData.customColors.background);
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Add glow effect if selected
    if (modData.effects.includes('glow')) {
      const glow = ctx.createRadialGradient(
        canvas.width / 2,
        canvas.height / 3,
        0,
        canvas.width / 2,
        canvas.height / 3,
        canvas.width * 0.6
      );
      glow.addColorStop(0, `${modData.customColors.primary}40`);
      glow.addColorStop(1, 'transparent');
      ctx.fillStyle = glow;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    // Draw header
    ctx.fillStyle = modData.customColors.primary;
    ctx.font = 'bold 72px Orbitron, sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    
    // Add gradient text effect if selected
    if (modData.effects.includes('gradient')) {
      const textGradient = ctx.createLinearGradient(0, 100, canvas.width, 100);
      textGradient.addColorStop(0, modData.customColors.primary);
      textGradient.addColorStop(0.5, modData.customColors.accent);
      textGradient.addColorStop(1, modData.customColors.primary);
      ctx.fillStyle = textGradient;
    }
    
    ctx.fillText(modData.modName || 'MOD NAME', canvas.width / 2, 120);

    // Draw version and author
    ctx.fillStyle = modData.customColors.secondary;
    ctx.font = 'bold 32px Rajdhani, sans-serif';
    ctx.fillText(`v${modData.version} • by ${modData.author}`, canvas.width / 2, 180);

    // Draw thumbnail area
    const thumbX = 80;
    const thumbY = 250;
    const thumbWidth = canvas.width - 160;
    const thumbHeight = 540;

    // Draw thumbnail background
    ctx.fillStyle = '#000';
    ctx.fillRect(thumbX, thumbY, thumbWidth, thumbHeight);

    // Draw thumbnail if exists
    if (modData.thumbnail) {
      const img = new Image();
      img.onload = () => {
        ctx.drawImage(img, thumbX, thumbY, thumbWidth, thumbHeight);
      };
      img.src = modData.thumbnail;
    } else {
      ctx.fillStyle = modData.customColors.secondary + '40';
      ctx.font = 'bold 48px Rajdhani, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText('THUMBNAIL PREVIEW', canvas.width / 2, thumbY + thumbHeight / 2);
    }

    // Draw thumbnail border
    ctx.strokeStyle = modData.customColors.accent;
    ctx.lineWidth = 4;
    ctx.strokeRect(thumbX, thumbY, thumbWidth, thumbHeight);

    // Draw badge
    if (modData.tagValue) {
      ctx.fillStyle = modData.customColors.accent;
      ctx.font = 'bold 28px Orbitron, sans-serif';
      const badgeWidth = ctx.measureText(modData.tagValue).width + 40;
      const badgeX = thumbX + 20;
      const badgeY = thumbY + 20;
      
      ctx.fillRect(badgeX, badgeY, badgeWidth, 50);
      ctx.fillStyle = '#fff';
      ctx.fillText(modData.tagValue, badgeX + 20, badgeY + 32);
    }

    // Draw description
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 36px Rajdhani, sans-serif';
    ctx.textAlign = 'left';
    ctx.fillText('DESCRIPTION', 80, thumbY + thumbHeight + 60);
    
    ctx.fillStyle = modData.customColors.secondary;
    ctx.font = '24px Rajdhani, sans-serif';
    const descriptionLines = wrapText(ctx, modData.description, 80, thumbY + thumbHeight + 100, canvas.width - 160, 30);
    
    // Draw details section
    const detailsY = thumbY + thumbHeight + 60 + descriptionLines * 35 + 40;
    
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 36px Rajdhani, sans-serif';
    ctx.fillText('DETAILS', 80, detailsY);

    // Draw details grid
    const details = [
      { label: 'Category', value: modData.category },
      { label: 'Downloads', value: modData.downloads },
      { label: 'File Size', value: modData.fileSize },
      { label: 'Rating', value: '★'.repeat(modData.rating) + '☆'.repeat(5 - modData.rating) },
      { label: 'Release Date', value: modData.releaseDate },
      { label: 'Last Update', value: modData.updateDate }
    ];

    details.forEach((detail, index) => {
      const row = Math.floor(index / 2);
      const col = index % 2;
      const x = 80 + col * (canvas.width / 2 - 40);
      const y = detailsY + 60 + row * 50;

      ctx.fillStyle = modData.customColors.primary;
      ctx.font = 'bold 24px Rajdhani, sans-serif';
      ctx.fillText(detail.label + ':', x, y);

      ctx.fillStyle = '#fff';
      ctx.font = '24px Rajdhani, sans-serif';
      ctx.fillText(detail.value, x + 180, y);
    });

    // Draw compatibility
    const compatY = detailsY + 60 + Math.ceil(details.length / 2) * 50 + 40;
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 36px Rajdhani, sans-serif';
    ctx.fillText('COMPATIBILITY', 80, compatY);

    ctx.fillStyle = modData.customColors.secondary;
    ctx.font = '24px Rajdhani, sans-serif';
    modData.compatibility.forEach((comp, index) => {
      const x = 80 + (index % 3) * 300;
      const y = compatY + 60 + Math.floor(index / 3) * 40;
      ctx.fillText('✓ ' + comp, x, y);
    });

    // Draw download section
    const downloadY = compatY + 60 + Math.ceil(modData.compatibility.length / 3) * 40 + 40;
    
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 36px Rajdhani, sans-serif';
    ctx.fillText('DOWNLOAD', 80, downloadY);

    ctx.fillStyle = modData.customColors.primary;
    ctx.font = 'bold 32px Rajdhani, sans-serif';
    ctx.textAlign = 'center';
    ctx.fillText('LINK IN COMMENTS / BIO', canvas.width / 2, downloadY + 60);

    // Draw website link
    ctx.fillStyle = modData.customColors.secondary;
    ctx.font = '24px Rajdhani, sans-serif';
    ctx.fillText('Website: bncraft1.github.io/BNcraft.github.io/BNcraft-Official-Links.html', canvas.width / 2, downloadY + 110);

    // Add watermark if enabled
    if (modData.watermark) {
      ctx.fillStyle = '#ffffff20';
      ctx.font = 'bold 48px Orbitron, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.save();
      ctx.translate(canvas.width / 2, canvas.height / 2);
      ctx.rotate(-Math.PI / 4);
      ctx.fillText(modData.watermarkText || 'BN MOD GENERATOR', 0, 0);
      ctx.restore();
    }

    // Add scanlines effect if selected
    if (modData.effects.includes('scanlines')) {
      ctx.fillStyle = '#00000010';
      for (let y = 0; y < canvas.height; y += 4) {
        ctx.fillRect(0, y, canvas.width, 1);
      }
    }

    // Add film grain effect if selected
    if (modData.effects.includes('noise')) {
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imageData.data;
      for (let i = 0; i < data.length; i += 4) {
        const noise = Math.random() * 20 - 10;
        data[i] += noise;
        data[i + 1] += noise;
        data[i + 2] += noise;
      }
      ctx.putImageData(imageData, 0, 0);
    }

    // Add vignette effect if selected
    if (modData.effects.includes('vignette')) {
      const vignette = ctx.createRadialGradient(
        canvas.width / 2,
        canvas.height / 2,
        0,
        canvas.width / 2,
        canvas.height / 2,
        canvas.width * 0.8
      );
      vignette.addColorStop(0, 'transparent');
      vignette.addColorStop(1, '#00000060');
      ctx.fillStyle = vignette;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

  }, [modData, canvasRef]);

  // Helper function to wrap text
  const wrapText = (ctx: CanvasRenderingContext2D, text: string, x: number, y: number, maxWidth: number, lineHeight: number) => {
    const words = text.split(' ');
    let line = '';
    let lines = 0;

    for (let n = 0; n < words.length; n++) {
      const testLine = line + words[n] + ' ';
      const metrics = ctx.measureText(testLine);
      const testWidth = metrics.width;
      
      if (testWidth > maxWidth && n > 0) {
        ctx.fillText(line, x, y);
        line = words[n] + ' ';
        y += lineHeight;
        lines++;
      } else {
        line = testLine;
      }
    }
    ctx.fillText(line, x, y);
    return lines + 1;
  };

  return (
    <div ref={containerRef} className="relative">
      <canvas
        ref={canvasRef}
        className="w-full max-w-2xl rounded-2xl shadow-2xl border-4 border-cyan-500/20"
      />
      <div className="absolute top-4 right-4 bg-black/70 text-white text-xs px-3 py-1 rounded-full">
        {canvasRef.current?.width}×{canvasRef.current?.height}px
      </div>
    </div>
  );
};