import React, { useRef, useState } from 'react';
import { Upload, X } from 'lucide-react';

interface ImageUploadProps {
  onImageUpload: (image: string) => void;
  currentImage: string | null;
}

export const ImageUpload: React.FC<ImageUploadProps> = ({ onImageUpload, currentImage }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [dragOver, setDragOver] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleFileSelect = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setError('Please select an image file');
      return;
    }

    if (file.size > 10 * 1024 * 1024) {
      setError('Image size should be less than 10MB');
      return;
    }

    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        if (img.width < 400 || img.height < 225) {
          setError('Image should be at least 400x225 pixels');
          return;
        }
        onImageUpload(e.target?.result as string);
        setError(null);
      };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) handleFileSelect(file);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragOver(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFileSelect(file);
  };

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragOver(true);
  };

  const handleDragLeave = () => {
    setDragOver(false);
  };

  const handleRemoveImage = () => {
    onImageUpload('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="space-y-3">
      <label className="block text-sm font-medium text-cyan-300 uppercase tracking-wider">
        Thumbnail Image (16:9 Recommended)
      </label>
      
      <div
        className={`relative border-2 border-dashed rounded-xl transition-all duration-200 ${
          dragOver
            ? 'border-cyan-500 bg-cyan-900/20'
            : 'border-cyan-400/40 bg-slate-900/30 hover:bg-slate-900/50'
        } ${currentImage ? 'aspect-video' : 'h-48'}`}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onClick={() => fileInputRef.current?.click()}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileChange}
          className="hidden"
        />
        
        {currentImage ? (
          <div className="relative w-full h-full">
            <img
              src={currentImage}
              alt="Preview"
              className="w-full h-full object-cover rounded-lg"
            />
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleRemoveImage();
              }}
              className="absolute top-2 right-2 p-2 bg-red-600/80 hover:bg-red-700 rounded-full text-white transition-colors"
            >
              <X size={16} />
            </button>
          </div>
        ) : (
          <div className="flex flex-col items-center justify-center h-full p-6 cursor-pointer">
            <Upload className="w-12 h-12 text-cyan-400/60 mb-3" />
            <p className="text-cyan-300/70 text-sm font-medium mb-1">
              Click or drag & drop
            </p>
            <p className="text-cyan-400/50 text-xs">
              PNG, JPG, WEBP up to 10MB
            </p>
            <p className="text-cyan-400/40 text-xs mt-1">
              Recommended: 1280×720px
            </p>
          </div>
        )}
      </div>

      {error && (
        <p className="text-red-400 text-sm flex items-center gap-2">
          <i className="fas fa-exclamation-circle"></i>
          {error}
        </p>
      )}

      {currentImage && !error && (
        <div className="flex items-center justify-between text-sm">
          <span className="text-green-400">
            <i className="fas fa-check-circle mr-2"></i>
            Image loaded successfully
          </span>
          <button
            type="button"
            onClick={handleRemoveImage}
            className="text-cyan-300 hover:text-cyan-100 text-xs flex items-center gap-1"
          >
            <i className="fas fa-trash"></i>
            Remove
          </button>
        </div>
      )}
    </div>
  );
};