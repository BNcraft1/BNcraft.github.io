import React from 'react';

interface ColorPickerProps {
  label: string;
  color: string;
  onChange: (color: string) => void;
  description?: string;
}

export const ColorPicker: React.FC<ColorPickerProps> = ({ 
  label, 
  color, 
  onChange,
  description 
}) => {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <label className="text-sm font-medium text-cyan-300 uppercase tracking-wider">
          {label}
        </label>
        <span className="text-xs text-cyan-400/60 font-mono">{color}</span>
      </div>
      
      <div className="flex items-center gap-3">
        <div className="relative">
          <input
            type="color"
            value={color}
            onChange={(e) => onChange(e.target.value)}
            className="w-12 h-12 cursor-pointer rounded-lg border-2 border-slate-700 bg-transparent"
          />
          <div 
            className="absolute inset-0 rounded-lg border-2 border-white/20 pointer-events-none"
            style={{ backgroundColor: color }}
          />
        </div>
        
        <input
          type="text"
          value={color}
          onChange={(e) => onChange(e.target.value)}
          className="flex-1 px-3 py-2 bg-slate-900/50 border border-cyan-800/30 rounded-lg text-white font-mono text-sm focus:outline-none focus:border-cyan-500"
          placeholder="#000000"
        />
      </div>
      
      {description && (
        <p className="text-xs text-cyan-400/50">{description}</p>
      )}
    </div>
  );
};