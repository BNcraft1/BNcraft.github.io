import React from 'react';
import { Template } from '../types';

interface TemplateSelectorProps {
  templates: Template[];
  selectedTemplate: string;
  onSelect: (templateId: string) => void;
}

export const TemplateSelector: React.FC<TemplateSelectorProps> = ({
  templates,
  selectedTemplate,
  onSelect
}) => {
  return (
    <div className="space-y-3">
      <label className="block text-sm font-medium text-cyan-300 uppercase tracking-wider">
        Design Template
      </label>
      
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {templates.map((template) => (
          <button
            key={template.id}
            type="button"
            onClick={() => onSelect(template.id)}
            className={`relative p-3 rounded-xl border-2 transition-all duration-200 ${
              selectedTemplate === template.id
                ? 'border-cyan-500 bg-cyan-900/20 scale-105'
                : 'border-slate-700 bg-slate-900/30 hover:bg-slate-900/50 hover:border-slate-600'
            }`}
          >
            <div className="space-y-2">
              <div className="flex items-center justify-center gap-2">
                <div 
                  className="w-4 h-4 rounded-full border border-white/20"
                  style={{ backgroundColor: template.colors.primary }}
                />
                <div 
                  className="w-4 h-4 rounded-full border border-white/20"
                  style={{ backgroundColor: template.colors.secondary }}
                />
                <div 
                  className="w-4 h-4 rounded-full border border-white/20"
                  style={{ backgroundColor: template.colors.accent }}
                />
              </div>
              
              <div className="text-center">
                <p className="text-xs font-semibold text-white truncate">
                  {template.name}
                </p>
                <p className="text-[10px] text-cyan-400/60 mt-1 line-clamp-2">
                  {template.description}
                </p>
              </div>
            </div>
            
            {selectedTemplate === template.id && (
              <div className="absolute -top-1 -right-1 w-5 h-5 bg-cyan-500 rounded-full flex items-center justify-center">
                <i className="fas fa-check text-white text-xs"></i>
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
};