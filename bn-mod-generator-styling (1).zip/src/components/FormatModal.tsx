import React from 'react';
import { X } from 'lucide-react';
import { FormatOption } from '../types';

interface FormatModalProps {
  isOpen: boolean;
  onClose: () => void;
  formats: FormatOption[];
  onDownload: (format: FormatOption) => void;
}

export const FormatModal: React.FC<FormatModalProps> = ({
  isOpen,
  onClose,
  formats,
  onDownload
}) => {
  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4 animate-fadeIn"
      onClick={onClose}
    >
      <div 
        className="bg-gradient-to-br from-slate-900 to-slate-800 border border-cyan-500/30 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="border-b border-cyan-500/20 p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center">
                <i className="fas fa-download text-white"></i>
              </div>
              <div>
                <h3 className="text-xl font-bold text-white font-orbitron tracking-wider">
                  Download Format
                </h3>
                <p className="text-cyan-400/70 text-sm">
                  Choose your preferred image format
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-slate-800 rounded-lg transition-colors text-slate-400 hover:text-white"
            >
              <X size={24} />
            </button>
          </div>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {formats.map((format) => (
              <button
                key={format.id}
                onClick={() => format.supported && onDownload(format)}
                disabled={!format.supported}
                className={`p-4 rounded-xl border-2 transition-all duration-200 flex flex-col items-center justify-center gap-2 ${
                  format.supported
                    ? 'border-cyan-500/30 bg-slate-800/50 hover:bg-slate-800 hover:border-cyan-500 hover:scale-105 cursor-pointer'
                    : 'border-slate-700 bg-slate-900/30 cursor-not-allowed opacity-60'
                }`}
              >
                <div className={`text-2xl ${format.supported ? 'text-cyan-400' : 'text-slate-500'}`}>
                  {format.id === 'png' && '🖼️'}
                  {format.id === 'jpg' && '📷'}
                  {format.id === 'webp' && '🌐'}
                  {format.id === 'svg' && '📐'}
                  {format.id === 'bmp' && '💾'}
                  {format.id === 'ico' && '🎯'}
                  {format.id === 'avif' && '🚀'}
                  {format.id === 'tiff' && '🖨️'}
                </div>
                
                <div className="text-center">
                  <p className={`font-bold text-lg ${format.supported ? 'text-white' : 'text-slate-400'}`}>
                    {format.name}
                  </p>
                  <p className="text-xs mt-1">
                    <span className={format.supported ? 'text-green-400' : 'text-red-400'}>
                      {format.supported ? '✓ Supported' : '✗ Not Supported'}
                    </span>
                  </p>
                  <p className="text-xs text-cyan-400/60 mt-2 line-clamp-2">
                    {format.description}
                  </p>
                </div>
                
                {format.supported && (
                  <div className="mt-2 px-3 py-1 bg-cyan-900/30 border border-cyan-500/30 rounded-full">
                    <span className="text-xs text-cyan-300">. {format.extension}</span>
                  </div>
                )}
              </button>
            ))}
          </div>

          <div className="mt-8 pt-6 border-t border-slate-700">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
              <div className="text-center p-3 bg-slate-800/30 rounded-lg">
                <p className="text-green-400 font-semibold">Best Quality</p>
                <p className="text-slate-400 text-xs mt-1">PNG, BMP, SVG</p>
              </div>
              <div className="text-center p-3 bg-slate-800/30 rounded-lg">
                <p className="text-cyan-400 font-semibold">Web Optimized</p>
                <p className="text-slate-400 text-xs mt-1">JPG, WebP</p>
              </div>
              <div className="text-center p-3 bg-slate-800/30 rounded-lg">
                <p className="text-purple-400 font-semibold">Special Use</p>
                <p className="text-slate-400 text-xs mt-1">ICO, AVIF, TIFF</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};