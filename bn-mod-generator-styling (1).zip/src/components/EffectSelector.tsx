import React from 'react';
import { Effect } from '../types';

interface EffectSelectorProps {
  effects: Effect[];
  selectedEffects: string[];
  onToggle: (effectId: string) => void;
}

export const EffectSelector: React.FC<EffectSelectorProps> = ({
  effects,
  selectedEffects,
  onToggle
}) => {
  return (
    <div className="space-y-3">
      <label className="block text-sm font-medium text-cyan-300 uppercase tracking-wider">
        Visual Effects
      </label>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {effects.map((effect) => (
          <button
            key={effect.id}
            type="button"
            onClick={() => onToggle(effect.id)}
            className={`relative p-3 rounded-xl border-2 transition-all duration-200 ${
              selectedEffects.includes(effect.id)
                ? 'border-purple-500 bg-purple-900/20'
                : 'border-slate-700 bg-slate-900/30 hover:bg-slate-900/50 hover:border-slate-600'
            }`}
          >
            <div className="space-y-2">
              <div className="flex items-center justify-center text-2xl">
                {effect.icon}
              </div>
              
              <div className="text-center">
                <p className="text-xs font-semibold text-white truncate">
                  {effect.name}
                </p>
                <p className="text-[10px] text-cyan-400/60 mt-1 line-clamp-2">
                  {effect.description}
                </p>
              </div>
            </div>
            
            {selectedEffects.includes(effect.id) && (
              <div className="absolute -top-1 -right-1 w-5 h-5 bg-purple-500 rounded-full flex items-center justify-center">
                <i className="fas fa-check text-white text-xs"></i>
              </div>
            )}
          </button>
        ))}
      </div>
    </div>
  );
};