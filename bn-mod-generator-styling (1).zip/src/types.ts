export interface ModData {
  modName: string;
  modLink: string;
  tagValue: string;
  thumbnail: string | null;
  version: string;
  author: string;
  description: string;
  category: string;
  rating: number;
  downloads: string;
  fileSize: string;
  compatibility: string[];
  releaseDate: string;
  updateDate: string;
  changelog: string;
  dependencies: string[];
  tags: string[];
  customColors: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
  };
  template: string;
  effects: string[];
  watermark: boolean;
  watermarkText: string;
  socialLinks: {
    discord: string;
    twitter: string;
    youtube: string;
    website: string;
  };
}

export interface Template {
  id: string;
  name: string;
  description: string;
  colors: {
    primary: string;
    secondary: string;
    accent: string;
    background: string;
  };
}

export interface Effect {
  id: string;
  name: string;
  description: string;
  icon: string;
}

export interface FormatOption {
  id: string;
  name: string;
  extension: string;
  description: string;
  quality: number;
  supported: boolean;
}