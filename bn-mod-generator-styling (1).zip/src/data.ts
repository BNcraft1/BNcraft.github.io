import { Template, Effect, FormatOption } from './types';

export const TEMPLATES: Template[] = [
  {
    id: 'modern',
    name: 'Modern Blue',
    description: 'Clean blue gradient with modern design',
    colors: {
      primary: '#00d4ff',
      secondary: '#0077ff',
      accent: '#005ccc',
      background: '#0d2b72'
    }
  },
  {
    id: 'dark',
    name: 'Dark Neon',
    description: 'Dark theme with neon accents',
    colors: {
      primary: '#00ff88',
      secondary: '#00ccff',
      accent: '#ff00ff',
      background: '#0a0a1a'
    }
  },
  {
    id: 'vintage',
    name: 'Vintage',
    description: 'Retro gaming style',
    colors: {
      primary: '#ff9900',
      secondary: '#cc6600',
      accent: '#663300',
      background: '#1a0f0a'
    }
  },
  {
    id: 'cyberpunk',
    name: 'Cyberpunk',
    description: 'Cyberpunk aesthetic with pink and blue',
    colors: {
      primary: '#ff00ff',
      secondary: '#00ffff',
      accent: '#ffff00',
      background: '#0a0a2a'
    }
  },
  {
    id: 'minimal',
    name: 'Minimal',
    description: 'Clean and minimal design',
    colors: {
      primary: '#333333',
      secondary: '#666666',
      accent: '#999999',
      background: '#f5f5f5'
    }
  }
];

export const EFFECTS: Effect[] = [
  {
    id: 'glow',
    name: 'Glow Effect',
    description: 'Add glowing effect to text and elements',
    icon: '✨'
  },
  {
    id: 'shadow',
    name: 'Drop Shadow',
    description: 'Add realistic drop shadows',
    icon: '🌑'
  },
  {
    id: 'gradient',
    name: 'Gradient Text',
    description: 'Apply gradient to text',
    icon: '🌈'
  },
  {
    id: 'scanlines',
    name: 'Scanlines',
    description: 'Add retro scanline effect',
    icon: '📺'
  },
  {
    id: 'noise',
    name: 'Film Grain',
    description: 'Add film grain texture',
    icon: '🎞️'
  },
  {
    id: 'vignette',
    name: 'Vignette',
    description: 'Darken edges for focus',
    icon: '🔘'
  },
  {
    id: 'blur',
    name: 'Background Blur',
    description: 'Add background blur effect',
    icon: '🌀'
  },
  {
    id: 'pixel',
    name: 'Pixel Art',
    description: 'Convert to pixel art style',
    icon: '🎮'
  }
];

export const FORMATS: FormatOption[] = [
  {
    id: 'png',
    name: 'PNG',
    extension: 'png',
    description: 'Lossless quality, transparent background',
    quality: 1,
    supported: true
  },
  {
    id: 'jpg',
    name: 'JPG',
    extension: 'jpg',
    description: 'Web standard, smaller file size',
    quality: 0.95,
    supported: true
  },
  {
    id: 'webp',
    name: 'WebP',
    extension: 'webp',
    description: 'Modern format, best compression',
    quality: 0.9,
    supported: true
  },
  {
    id: 'svg',
    name: 'SVG',
    extension: 'svg',
    description: 'Vector format, scalable',
    quality: 1,
    supported: true
  },
  {
    id: 'bmp',
    name: 'BMP',
    extension: 'bmp',
    description: 'Raw pixel data',
    quality: 1,
    supported: true
  },
  {
    id: 'ico',
    name: 'ICO',
    extension: 'ico',
    description: 'Icon format (256x256)',
    quality: 1,
    supported: true
  },
  {
    id: 'avif',
    name: 'AVIF',
    extension: 'avif',
    description: 'Next-gen format',
    quality: 0.8,
    supported: false
  },
  {
    id: 'tiff',
    name: 'TIFF',
    extension: 'tiff',
    description: 'Professional printing',
    quality: 1,
    supported: false
  }
];

export const CATEGORIES = [
  'Add-Ons',
  'Texture-Pack',
  'World-Template',
  'Skin-Pack',
  'Mash-Up',
  'Gameplay',
  'Visual',
  'Audio',
  'Utility',
  'Library',
  'Framework',
  'Tool',
  'Script',
  'Plugin',
  'Extension'
];

export const COMPATIBILITY_OPTIONS = [
  'Minecraft 1.20+',
  'Minecraft 1.19+',
  'Minecraft 1.18+',
  'Forge',
  'Fabric',
  'Quilt',
  'OptiFine',
  'Sodium',
  'Iris',
  'Shaders'
];